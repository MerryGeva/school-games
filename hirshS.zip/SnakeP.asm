;enter none
;exit reset the variables
proc gameStart
    graphicMode
    mov [len],0
    mov [score],0
    mov [direction],2 ;start with left 1=right 2=left 3=up 4=down
    mov [chackSlf],0;0=don't hit the body 1= hit the body
    mov [chackApl],0;0=don't eat apple  1= eat apple
ret    
endp gameStart

;enter skin
;exit sets the right skin 
proc setSkinR
   
    cmp [skin],1;green
    je greenR
    cmp [skin],2;blue
    je blueR
    cmp [skin],3;red
    je redR
    cmp [skin],4;purple
    je purpR
    cmp [skin],5;green black
    je greenBR
    cmp [skin],6;blue black
    je blueBR
    cmp [skin],7;red black
    je redBR
    cmp [skin],8;purple black
    je purpBR
    cmp [skin],9;snowman
    je snowR
    
greenR:    
    setDmut snakeG
    drawS ;drawing snake 
    setDmut snakeHRG;head
    jmp doneR
    
blueR:    
    setDmut snakeB
    drawS ;drawing snake  
    setDmut snakeHRB;head
    jmp doneR
   
redR:    
    setDmut snakeR
    drawS ;drawing snake 
    setDmut snakeHRR;head
    jmp doneR
    
purpR:    
    setDmut snakeP
    drawS ;drawing snake 
    setDmut snakeHRP;head
    jmp doneR
    
greenBR:    
    setDmut snakeGb
    drawS ;drawing snake 
    setDmut snakeHRGb;head
    jmp doneR
    
blueBR:    
    setDmut snakeBb
    drawS ;drawing snake  
    setDmut snakeHRBb;head
    jmp doneR
   
redBR:    
    setDmut snakeRb
    drawS ;drawing snake 
    setDmut snakeHRRb;head
    jmp doneR
    
purpBR:    
    setDmut snakePb
    drawS ;drawing snake 
    setDmut snakeHRPb;head
    jmp doneR
    
snowR:    
    setDmut snakeSn
    drawS ;drawing snake 
    setDmut snakeHRSn;head
    jmp doneR
    
doneR:
    
ret
endp setSkinR

;enter skin
;exit sets the left skin 
proc setSkinL
   
    cmp [skin],1;green
    je greenL
    cmp [skin],2;blue
    je blueL
    cmp [skin],3;red
    je redL
    cmp [skin],4;purple
    je purpL
    cmp [skin],5;green black
    je greenBL
    cmp [skin],6;blue black
    je blueBL
    cmp [skin],7;red black
    je redBL
    cmp [skin],8;purple black
    je purpBL
    cmp [skin],9;snowman
    je snowL
    
greenL:    
    setDmut snakeG
    drawS ;drawing snake 
    setDmut snakeHLG;head
    jmp doneL
    
blueL:    
    setDmut snakeB
    drawS ;drawing snake  
    setDmut snakeHLB;head
    jmp doneL
   
redL:    
    setDmut snakeR
    drawS ;drawing snake 
    setDmut snakeHLR;head
    jmp doneL
    
purpL:    
    setDmut snakeP
    drawS ;drawing snake 
    setDmut snakeHLP;head
    jmp doneL
    
greenBL:    
    setDmut snakeGb
    drawS ;drawing snake 
    setDmut snakeHLGb;head
    jmp doneL
    
blueBL:    
    setDmut snakeBb
    drawS ;drawing snake  
    setDmut snakeHLBb;head
    jmp doneL
   
redBL:    
    setDmut snakeRb
    drawS ;drawing snake 
    setDmut snakeHLRb;head
    jmp doneL
    
purpBL:    
    setDmut snakePb
    drawS ;drawing snake 
    setDmut snakeHLPb;head
    jmp doneL
    
snowL:    
    setDmut snakeSn
    drawS ;drawing snake 
    setDmut snakeHLSn;head
    jmp doneL
    
doneL:
    
ret
endp setSkinL
    

;enter skin
;exit sets the up skin 
proc setSkinU
   
    cmp [skin],1;green
    je greenU
    cmp [skin],2;blue
    je blueU
    cmp [skin],3;red
    je redU
    cmp [skin],4;purple
    je purpU
    cmp [skin],5;green black
    je greenBU
    cmp [skin],6;blue black
    je blueBU
    cmp [skin],7;red black
    je redBU
    cmp [skin],8;purple black
    je purpBU
    cmp [skin],9;snowman
    je snowU
    
greenU:    
    setDmut snakeG
    drawS ;drawing snake 
    setDmut snakeHUG;head
    jmp doneU
    
blueU:    
    setDmut snakeB
    drawS ;drawing snake  
    setDmut snakeHUB;head
    jmp doneU
   
redU:    
    setDmut snakeR
    drawS ;drawing snake 
    setDmut snakeHUR;head
    jmp doneU
    
purpU:    
    setDmut snakeP
    drawS ;drawing snake 
    setDmut snakeHUP;head
    jmp doneU
     
greenBU:    
    setDmut snakeGb
    drawS ;drawing snake 
    setDmut snakeHUGb;head
    jmp doneU
    
blueBU:    
    setDmut snakeBb
    drawS ;drawing snake  
    setDmut snakeHUBb;head
    jmp doneU
   
redBU:    
    setDmut snakeRb
    drawS ;drawing snake 
    setDmut snakeHURb;head
    jmp doneU
    
purpBU:    
    setDmut snakePb
    drawS ;drawing snake 
    setDmut snakeHUPb;head
    jmp doneU
    
snowU:    
    setDmut snakeSn
    drawS ;drawing snake 
    setDmut snakeHUSn;head
    jmp doneU
    
doneU:
    
ret
endp setSkinU

;enter skin
;exit sets the down skin 
proc setSkinD
   
    cmp [skin],1;green
    je greenD
    cmp [skin],2;blue
    je blueD
    cmp [skin],3;red
    je redD
    cmp [skin],4;purple
    je purpD
    cmp [skin],5;green black
    je greenBD
    cmp [skin],6;blue black
    je blueBD
    cmp [skin],7;red black
    je redBD
    cmp [skin],8;purple black
    je purpBD
    cmp [skin],9;snowman
    je snowD
    
greenD:    
    setDmut snakeG
    drawS ;drawing snake 
    setDmut snakeHDG;head
    jmp doneD
    
blueD:    
    setDmut snakeB
    drawS ;drawing snake  
    setDmut snakeHDB;head
    jmp doneD
   
redD:    
    setDmut snakeR
    drawS ;drawing snake 
    setDmut snakeHDR;head
    jmp doneD
    
purpD:    
    setDmut snakeP
    drawS ;drawing snake 
    setDmut snakeHDP;head
    jmp doneD
     
greenBD:    
    setDmut snakeGb
    drawS ;drawing snake 
    setDmut snakeHDGb;head
    jmp doneD
    
blueBD:    
    setDmut snakeBb
    drawS ;drawing snake  
    setDmut snakeHDBb;head
    jmp doneD
   
redBD:    
    setDmut snakeRb
    drawS ;drawing snake 
    setDmut snakeHDRb;head
    jmp doneD
    
purpBD:    
    setDmut snakePb
    drawS ;drawing snake 
    setDmut snakeHDPb;head
    jmp doneD
    
snowD:    
    setDmut snakeSn
    drawS ;drawing snake 
    setDmut snakeHDSn;head
    jmp doneD
    
doneD:
    
ret
endp setSkinD

;enter skin
;exit sets the starting head
proc startSkinH
   
    cmp [skin],1;green
    je gHead
    cmp [skin],2;blue
    je bHead
    cmp [skin],3;red
    je rHead
    cmp [skin],4;purple
    je pHead
    cmp [skin],5;green black
    je gBHead
    cmp [skin],6;blue black
    je bBHead
    cmp [skin],7;red black
    je rBHead
    cmp [skin],8;purple black
    je pBHead
    cmp [skin],9;purple black
    je SnHead
    
gHead:     
    setDmut snakeHLG;head
    drawS ;drawing snake
    jmp @@stop
    
bHead:     
    setDmut snakeHLB;head
    drawS ;drawing snake
    jmp @@stop
    
rHead:     
    setDmut snakeHLR;head
    drawS ;drawing snake
    jmp @@stop
    
pHead:     
    setDmut snakeHLP;head
    drawS ;drawing snake
    jmp @@stop
    
gBHead:    
    setDmut snakeHLGb;head
    drawS ;drawing snake 
    jmp @@stop
    
bBHead:    
    setDmut snakeHLBb;head
    drawS ;drawing snake 
    jmp @@stop
   
rBHead:    
    setDmut snakeHLRb;head
    drawS ;drawing snake 
    jmp @@stop
    
pBHead:    
    setDmut snakeHLPb;head
    drawS ;drawing snake 
    jmp @@stop
    
SnHead:    
    setDmut snakeHLSn;head
    drawS ;drawing snake 
    jmp @@stop
    
@@stop:
    
ret
endp startSkinH

;enter skin
;exit sets the starting body
proc startSkinBd
   
    cmp [skin],1;green
    je gBody
    cmp [skin],2;blue
    je bBody
    cmp [skin],3;red
    je rBody
    cmp [skin],4;purple
    je pBody
    cmp [skin],5;green black
    je gBBody
    cmp [skin],6;blue black
    je bBBody
    cmp [skin],7;red black
    je rBBody
    cmp [skin],8;purple black
    je pBBody
    cmp [skin],9;purple black
    je SnBody
    
gBody:     
    setDmut snakeG;body
    drawS ;drawing snake
    jmp @@stop
    
bBody:     
    setDmut snakeB;body
    drawS ;drawing snake
    jmp @@stop
    
rBody:     
    setDmut snakeR;body
    drawS ;drawing snake
    jmp @@stop
    
pBody:     
    setDmut snakeP;body
    drawS ;drawing snake
    jmp @@stop
    
gBBody:    
    setDmut snakeGb;head
    drawS ;drawing snake 
    jmp @@stop
    
bBBody:    
    setDmut snakeBb;head
    drawS ;drawing snake 
    jmp @@stop
   
rBBody:    
    setDmut snakeRb;head
    drawS ;drawing snake 
    jmp @@stop
    
pBBody:    
    setDmut snakePb;head
    drawS ;drawing snake 
    jmp @@stop
    
SnBody:    
    setDmut snakeSn;head
    drawS ;drawing snake 
    jmp @@stop
    
@@stop:
    
ret
endp startSkinBd

;enter none
;exit drawing the background and snake
proc drawBackground
    push ax dx
     ;draw green background 
     mov [color], 96
    mov [x], 0
    mov [y], 0
    setParam 320, 200
    call drawSQ
    
    ;draw the end lines  
    mov [color], 6
    mov [x], 0
    mov [y], 0
    setParam 320,28
    call drawSQ
    
    ;draw the end lines  
    mov [color], 6
    mov [x], 0
    mov [y], 188
    setParam 320,12
    call drawSQ
    
   ;draw the end lines 
    mov [color], 6
    mov [x], 312
    mov [y], 0
    setParam 8,200
    call drawSQ
    
    ;draw the end lines  
    mov [color], 6
    mov [x], 0
    mov [y], 0
    setParam 8,200
    call drawSQ
    
    
    ;middle of screen draw head
    mov ax,152
    mov [snakeX],ax ;save x
    mov [x],ax
    mov ax,92
    mov [snakeY],ax ;save y
    mov [y],ax
    setParam 16,16
    inc [len]
    call startSkinH
    
    ;next block
    mov ax,168
    mov [snakeX+2],ax ;save x
    mov [x],ax
    mov ax,92
    mov [snakeY+2],ax ;save y
    mov [y],ax 
    setParam 16,16
    inc [len]
    call startSkinBd
      
    ;next block
    mov ax,184
    mov [snakeX+4],ax ;save x
    mov [x],ax
    mov ax,92
    mov [snakeY+4],ax ;save y
    mov [y],ax 
    setParam 16,16
    inc [len]
    call startSkinBd
    
    ;generate random coordinates
    call randomAp
  
    ;draw apple
    mov ax,[appleX] ;save x
    mov [x],ax
    mov ax,[appleY];save y
    mov [y],ax
    setParam 16,16
    drawA ;drawing apple
    
    ;print score msg
    setCurser 1,13
    mov dx,offset scoreMsg
    mov ah,9h
    int 21h
    ;print score
    xor ax,ax
    mov al,[score]
    setCurser  1,19
    call printNumber
    
    pop dx ax
ret
endp drawBackground    
    
;enter pos high scrkeep wide
;exit take sqaure from pos
proc takeSQR
    push ax es di si cx
    mov ax, 0A000h
    mov es, ax  
    
    mov di, [pos]
    mov si, offset scrKeep
    
    mov cx, [high]
takeLine:
    push cx
    mov cx, [wide]
takeCol:
    mov al, [es:di]
    mov [si], al
    inc di
    inc si
    loop takeCol
    add di, 320
    sub di, [wide]
    pop cx
    loop takeLine
    pop cx si di es ax
ret
endp takeSQR

;enter pos high scrkeep wide
;exit return sceKeep to screen
proc retSQR
    push ax es di si cx
    mov ax, 0A000h
    mov es, ax
    
    mov di, [pos]
    mov si, offset scrKeep
    

    mov cx, [high]
retLine:
    push cx
    mov cx, [wide]
retcol:
    mov al, [si]
    mov [es:di], al
    inc di
    inc si
    loop retcol
    add di, 320
    sub di, [wide]
    pop cx
    loop retLine    
   
    pop cx si di es ax
ret
endp retSQR

;enter pos,high,dmutM,wide,snakeM
;exit anding between character and screen
proc andingS

    push ax es di si cx 
    mov ax, 0A000h
    mov es, ax
    
    mov di, [pos]
    mov si, offset snakeM
    mov cx, [high]

and2:
    push cx
    mov cx, [wide]
xxx:
    lodsb ; al <- ds:si
    and [es:di], al
    inc di
    loop xxx
    add di, 320
    sub di, [wide]
    pop cx
    loop and2

    pop cx si di es ax

ret
endp andingS


;enter pos,high,dmut,wide,snake
;exit oring between character and screen  
proc oringS

    push ax es di si cx 
    mov ax, 0A000h
    mov es, ax
    
    mov di, [pos]
    mov si,  [dmut]
    mov cx, [high]

or2:
    push cx
    mov cx, [wide]
yyy:
    lodsb ; al <- ds:si
    or [es:di], al
    inc di
    loop yyy
    add di, 320
    sub di, [wide]
    pop cx
    loop or2

    pop cx si di es ax

ret
endp oringS

;enter pos,high,dmutM,wide,appleM
;exit anding between character and screen
proc andingA

    push ax es di si cx 
    mov ax, 0A000h
    mov es, ax
    
    mov di, [pos]
    mov si, offset appleM
    mov cx, [high]

andA:
    push cx
    mov cx, [wide]
xA:
    lodsb ; al <- ds:si
    and [es:di], al
    inc di
    loop xA
    add di, 320
    sub di, [wide]
    pop cx
    loop andA

    pop cx si di es ax

ret
endp andingA


;enter pos,high,dmut,wide,apple
;exit oring between character and screen  
proc oringA

    push ax es di si cx 
    mov ax, 0A000h
    mov es, ax
    
    mov di, [pos]
    mov si, offset apple
    mov cx, [high]

orA:
    push cx
    mov cx, [wide]
yA:
    lodsb ; al <- ds:si
    or [es:di], al
    inc di
    loop yA
    add di, 320
    sub di, [wide]
    pop cx
    loop orA

    pop cx si di es ax

ret
endp oringA

;enter snakeX,snakeY
;exit drawing new head
proc newHeadR
    push ax
    ;delete prev head
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call calcPos
    call retSQR
        
    ;draw body   
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call setSkinR   
    
    ;next head place
    add [snakeX],16 
    mov ax,[snakeX]
    mov [x],ax
   
    mov ax,[snakeY]
    mov [y],ax
    
    drawS ;drawing snake
    
    pop ax
ret
endp newHeadR    

;enter snakeX,snakeY
;exit drawing new head
proc newHeadL
    push ax
    ;delete prev head
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call calcPos
    call retSQR
    
    ;draw body
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call setSkinL   
    
    ;next head place 
    sub [snakeX],16 
    mov ax,[snakeX]
    mov [x],ax
   
    mov ax,[snakeY]
    mov [y],ax
    
    ;draw head  
    drawS ;drawing snake 
    
    pop ax
ret
endp newHeadL 

;enter snakeX,snakeY
;exit drawing new head
proc newHeadU
    push ax
    ;delete prev head
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call calcPos
    call retSQR
    
    ;draw body
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call setSkinU  
    
    ;next head place
    mov ax,[snakeX]
    mov [x],ax
   
    sub [snakeY],16 
    mov ax,[snakeY]
    mov [y],ax
    
    ;draw head  
    drawS ;drawing snake
    
    pop ax
ret
endp newHeadU 

;enter snakeX,snakeY
;exit drawing new head
proc newHeadD
    push ax
    ;delete prev head
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call calcPos
    call retSQR
    
    ;draw body
    mov ax,[snakeX+2]
    mov [x],ax
   
    mov ax,[snakeY+2]
    mov [y],ax
    
    call setSkinD   
    
    ;next head place
    mov ax,[snakeX]
    mov [x],ax
   
    add [snakeY],16 
    mov ax,[snakeY]
    mov [y],ax
    
    ;draw head  
    drawS ;drawing snake 
    
    pop ax
ret
endp newHeadD 

; enter : x,y
; exit : number of pixel x+320*y in pos
proc calcPos
    push ax cx dx
    mov cx, [y]
    mov ax, 320
    mul cx  ; ax <- cx*ax
    add ax, [x]
    mov [pos], ax
    pop dx cx ax
ret

endp calcPos



;enter receives X,Y,Color
;exit print Pixel 
proc drawPixel
    push ax bx cx dx
    mov bh,0h
    mov cx,[x]
    mov dx,[y]
    mov al,[color]
    mov ah,0ch
    int 10h
    pop dx cx bx ax
ret
endp drawPixel

;enter receives X,wide
;exit print line
proc drawLine
    push cx [x]
    mov cx, [wide]
@@draw:
    call drawPixel
    inc [x]
    loop @@draw
    pop [x] cx
ret
endp drawLine

;enter receives Y,high
;exit print square
proc drawSQ
    push cx [y]
    mov cx, [high]
@@draw:
    call drawLine
    inc [y]
    loop @@draw
    pop [y] cx
ret
endp drawSQ
   
;enter snakeX snakeY
;exit deleting the old tail 
proc delTail
    push ax
    prepShR;si=(len-1)*2
    
    ;delete the tail
    mov ax,[snakeX + si+2]    
    mov [x],ax
    mov [snakeX + si+2],0
        
    mov ax,[snakeY + si+2]
    mov [y],ax
    mov [snakeY + si+2],0
    
    call calcPos
    call retSQR
    pop ax
ret
endp delTail    

;enter appleX appleY
;exit deleting the old apple 
proc delApple
    push ax
    ;delete the apple
    mov ax,[appleX]
    mov [x],ax
    mov ax,[appleY]
    mov [y],ax
    
    call calcPos
    call retSQR
    pop ax
ret
endp delApple

;enter appleX appleY
;exit drawing new apple 
proc drawApl
    push ax
    ;draw apple
    mov ax,[appleX] ;save x
    mov [x],ax
    mov ax,[appleY];save y
    mov [y],ax
    setParam 16,16
    drawA
    
    mov [chackApl],1;true
    pop ax
ret
endp drawApl
    
;enter cx
;exit delay time by the number in cx
proc delay 

    push ax [prevTime]
    takeTime
Delay:
    mov [prevTime],ax   ; Save the current time
WaitLoop:
    takeTime
    cmp ax, [prevTime]   ; Compare saved time with current time                   
    je WaitLoop     ; If timer hasn't changed keep waiting  
    loop Delay 
    pop [prevTime] ax
ret
endp delay

;enter cx,si
;moving every block in snakeX and snakeY right
proc shRight

    push ax cx si
   
rotateL:
    mov ax,[snakeX + si]
 
    mov [snakeX + si+2],ax
   
    mov ax,[snakeY + si]
    
    mov [snakeY + si+2],ax
    
    sub si,2
    
    loop rotateL
    
    pop si cx ax 
ret
endp shRight

;enter clock,cs,bx
;exit generate random number and put it in appleX
proc randomX
    push ax dx bx

    xor dx,dx
    ; generate random number
    takeTime  ; read timer counter
    mov bx,19    ; 0-18
    div bx      ; dx = remainder

    mov ax,dx
    inc ax ;1-19
    
    shl ax,4 ;dx*16
    sub ax,8
    
    mov [appleX],ax
    
    pop bx dx ax
ret
endp randomX

;enter clock,cs,bx
;exit generate random number and put it in appleY
proc randomY
    push ax dx bx

    xor dx,dx
    ; generate random number
    takeTime  ; read timer counter
    mov bx,10    ; 0-9
    div bx      ; dx = remainder

    mov ax,dx
    add ax,2 ;2-11
    
    shl ax,4 ;dx*16
    sub ax,4
    
    mov [appleY],ax
    
    pop bx dx ax
ret
endp randomY


;enter snakeX,snakeY,len
;exit generate random coordinates for the apple
proc randomAp
    push ax dx si

genRan:    
    xor dx,dx ; 0 for not equal 1 for equal
    call randomX
    call randomY
    
    xor cx,cx
    mov cl,[len];loop counter
    xor si,si
cmpApSn:    
    mov ax,[snakeX + si];compare x
    cmp [appleX],ax
    jne nextPart
    
    mov ax,[snakeY + si];compare y
    cmp [appleY],ax
    jne nextPart
    
    inc dx ;equal
    
nextPart:
    add si,2;next part of the snake
    loop cmpApSn
    
    cmp dx,1 ;if dx is equal generate another cordinates
    je genRan
    
    pop  si dx ax
ret
endp randomAp

;enter snakeX,snakeY,len,x,y
;exit chack if the snake hit itself
proc chackBd
    push ax cx si
    
    cmp [len],5
    jb stopBd

    xor cx,cx
    ;no need to chack first 4 
    mov cl,[len]
    sub cx,4 ;loop counter
    mov si,8
  
    mov [chackSlf],0; 0 for not equal 1 for equal

cmpBd:    
    mov ax,[snakeX + si];compare x
    cmp [x],ax
    jne nextBd
    
    mov ax,[snakeY + si];compare y
    cmp [y],ax
    jne nextBd
    
    inc [chackSlf]
    jmp stopBd
    
nextBd:
    
    add si,2;next part of the snake
    loop cmpBd
    
stopBd:
    
    pop  si cx ax
ret
endp chackBd


;enter Hz
;exit play sound
proc playSound
    push ax 
    
    frequency
    ; play frequency 
    mov ax, [Hz]   
    out 42h, al; sending lower byte
    mov al, ah
    out 42h, al; sending upper byte
       
    pop  ax
ret
endp playSound 


;enter none
;exit play the sound of eating apple 
proc aplSound
    push cx ax 
    
    openSpeaker
    
    mov [Hz],11D0h    ;  261 Hz
    call playSound
    mov cx,1; 1x0.055sec = 0.55sec
    call delay
       
    mov [Hz],0FDFh  ; 293 Hz
    call playSound
    mov cx,2; 2x0.055sec = 0.1sec
    call delay
    
    mov [Hz],0E23h  ; 329 Hz
    call playSound
    mov cx,2; 2x0.055sec = 0.1sec
    call delay
    
    closeSpeaker
    
    pop ax cx
ret
endp aplSound 

;enter none
;exit play the losing sound 
proc loseSound
    push cx ax
   
    openSpeaker
    
    mov [Hz],1137h    ;  270 Hz
    call playSound
    mov cx,3; 3x0.055sec = 0.15sec
    call delay
           
    mov [Hz],1B58h    ;  200 Hz
    call playSound
    mov cx,4; 4x0.055sec = 0.2sec
    call delay
    
    mov [Hz],2E7Ch    ;  100 Hz
    call playSound
    mov cx,6; 6x0.055sec = 0.3sec
    call delay
    
    closeSpeaker
    
    pop ax cx
ret
endp loseSound    
    
; enter character in al
; exit printing the character
proc printCharacter
    push ax dx ;save registers
    
    mov ah,2
    mov dl, al
    int 21h
    pop dx ax
    
ret
endp printCharacter

; enter number in ax,divTable
; exit printing the number
proc printNumber
    push ax bx dx
    
    mov bx,offset divTable
nextDigit:
    xor ah,ah   ; dx:ax = number
    div [byte ptr bx]    ; al = quotient, ah = remainder    
    add al,'0'
    call printCharacter     ; Display the quotient
    mov al,ah   ; ah = remainder
    inc bx        ; bx = address of next divisor
    cmp [byte ptr bx],1 ; Have all divisors been done?
    jne nextDigit
    ; handle the last digit
    add al,'0'
    call printCharacter     ; Display the quotient
    mov ah,2
    mov dl,13
    int 21h
    mov dl,10
    int 21h 
    Pop dx bx ax
ret
endp printNumber 

;enter  currentFile filehandle
;exit Open file, put handle in filehandle
proc OpenFile

    push ax dx 
    mov ah, 3Dh
    xor al, al
    mov dx, [currentFile]
    int 21h
    jc openerror
    mov [filehandle], ax
    pop dx ax
    jmp return

openerror:
    mov ax, 4c00h ; exit the program
    int 21h
return:    
ret
endp OpenFile

;enter filehandle Header
;exit Read BMP file header, 54 bytes
proc ReadHeader

    push ax bx cx dx
    mov ah,3fh
    mov bx, [filehandle]
    mov cx , 54
    mov dx,offset Header
    int 21h 
    pop dx cx bx ax
ret
endp ReadHeader

;enter filehandle Palette
;exit Read BMP file color palette, 256 
proc ReadPalette

    push ax bx cx dx
    mov ah,3fh
    mov bx, [filehandle]
    mov cx , 400h 
    mov dx,offset Palette
    int 21h 
    pop dx cx bx ax
ret
endp ReadPalette

;enter Palette
;exit Copy the colors palette to the video memory registers 
proc CopyPal

    push ax cx dx si
    mov si,offset Palette 
    mov cx,256 
    mov dx,3C8h
    mov al,0 
    ; Copy starting color to port 3C8h
    out dx,al
    ; Copy palette itself to port 3C9h
    inc dx 
PalLoop:
    ; Note: Colors in a BMP file are saved as BGR values rather than RGB.
    mov al,[si+2]   ; Get red value.
    shr al,2        ; Max. is 255, but video palette maximal
    ; value is 63. Therefore dividing by 4.
    out dx,al        ; Send it.
    mov al,[si+1]   ; Get green value.
    shr al,2
    out dx,al       ; Send it.
    mov al,[si]     ; Get blue value.
    shr al,2
    out dx,al       ; Send it.
    add si,4         ; Point to next color.
    ; (There is a null chr. after every color.)
    loop PalLoop
    pop si dx cx ax
ret
endp CopyPal

;enter filehandle  picHigh leftGap topGap picWidth ScrLine
;exit  Read the graphic line by line ,displaying the lines from bottom to top.
proc CopyBitmap
    ; BMP graphics are saved upside-down.
    ; Read the graphic line by line (200 lines in VGA format),
    ; displaying the lines from bottom to top.
    push ax bx cx dx di es
    mov ax, 0A000h
    mov es, ax
    mov bx, [filehandle]
    mov cx,[picHigh]
PrintBMPLoop:
    push cx
    ; di = cx*320, point to the correct screen line
    mov di,cx 
    shl cx,6 
    shl di,8 
    add di,cx

    add di,[leftGap]
    add di,[topGap]

    ; Read one line
    mov ah,3fh
    mov cx,[picWidth]
    mov dx,offset ScrLine
    int 21h 
    ; Copy one line into video memory
    cld         ; Clear direction flag, for movsb
    mov cx,320
    mov si,offset ScrLine
    rep movsb   ; Copy line to the screen
    pop cx
    loop PrintBMPLoop
    pop es di dx cx bx ax
ret
endp CopyBitmap

;enter  filehandle
;exit close the file
proc CloseFile

    push ax bx 
    mov ah,3Eh
    mov bx, [filehandle]
    int 21h
    pop bx ax
ret
endp CloseFile

;enter none
;exit draw the pic  
proc printPic
    call OpenFile
    call ReadHeader
    call ReadPalette
    call CopyPal
    call CopyBitmap
    call CloseFile
ret
endp printPic



; enter : scoreFile (filename)
; exit: topScores[0..4] filled from file
proc loadTop5

    push ax bx cx dx si        ; Save registers

    ; ----------------------------------------
    ; Open file for reading
    ; ----------------------------------------
    mov ah,3Dh                 ; open file
    mov al,0                   ; mode = read only
    mov dx,offset scoreFile    ; filename
    int 21h
    jc noFile                  ; if file not found -> init array

    mov [filehandle],ax        ; store file handle

    ; ----------------------------------------
    ; Read 5 bytes into topScores
    ; ----------------------------------------
    mov ah,3Fh                ; read file
    mov bx,[filehandle]       ; file handle
    mov cx,5                  ; number of bytes to read
    mov dx,offset topScores   ; destination buffer
    int 21h


    ; Close file

    call CloseFile
    jmp done

; If file does not exist ? initialize

noFile:
    xor si,si                 ; index = 0
    mov cx,5                  ; 5 entries

clearLoop:
    mov [topScores+si],0   ; set score = 0
    inc si
    loop clearLoop

done:
    pop si dx cx bx ax
ret
endp loadTop5


; enter : topScores[0..4]
; exit: file updated
proc saveTop5

    push ax bx cx dx

    ; ----------------------------------------
    ; Create / overwrite file
    ; ----------------------------------------
    mov ah,3Ch                 ; DOS create file
    mov cx,0                   ; normal attributes
    mov dx,offset scoreFile    ; filename
    int 21h

    mov [filehandle],ax        ; store handle

    ; ----------------------------------------
    ; Write 5 bytes to file
    ; ----------------------------------------
    mov ah,40h                 ; DOS write file
    mov bx,[filehandle]
    mov cx,5                  ; write 5 scores
    mov dx,offset topScores
    int 21h

    ; ----------------------------------------
    ; Close file
    ; ----------------------------------------
    call CloseFile

    pop dx cx bx ax
ret
endp saveTop5


; enter : score
; exit: updated topScores[0..4]
proc updateTop5

    push ax bx cx dx si

    xor bx,bx                  ; bx = index = 0

; ----------------------------------------
; Find correct position for new score
; ----------------------------------------
checkLoop:

    cmp bx,5                  ; reached end of list?
    je finish

    mov al,[score]            ; current score
    cmp al,[topScores+bx]     ; compare with entry

    ja insert                 ; if score is higher -> insert here

    inc bx
    jmp checkLoop

; ----------------------------------------
; Shift scores down to make space
; ----------------------------------------
insert:

    mov si,4                  ; start from last index (4)

shiftLoop:

    cmp si,bx                 ; stop when reaching insertion point
    jle doInsert

    mov al,[topScores+si-1]   ; copy previous score
    mov [topScores+si],al     ; shift right

    dec si
    jmp shiftLoop

; ----------------------------------------
; Insert new score
; ----------------------------------------
doInsert:

    mov al,[score]
    mov [topScores+bx],al

finish:

    pop si dx cx bx ax
ret
endp updateTop5

;enter topScores
;exit print the top scores
proc printTop5

    push ax
    ; first place
    setCurser 7,12
    mov al,[topScores]
    call printNumber

    ; second place
    setCurser 9,12
    mov al,[topScores+1]
    call printNumber

    ; third place
    setCurser 11,12
    mov al,[topScores+2]
    call printNumber

    ; fourth place
    setCurser 13,12
    mov al,[topScores+3]
    call printNumber

    ; fifth place
    setCurser 15,12
    mov al,[topScores+4]
    call printNumber

    pop ax
ret
endp printTop5
