include SnakeM.asm
jumps
IDEAL
P186
MODEL small 
STACK 100h
DATASEG
; --------------------------

include "DSnake.asm"

    Clock       equ es:6Ch ; System timer tick address
    
    high        dw  16 ; Current object height for drawing
    wide        dw  16 ; Current object width  for drawing
    
    x           dw ? ; Current X coordinate
    y           dw ? ; Current Y coordinate
    color       db ? ; color to draw with
    pos         dw ? ; position on screen(x + 320*y)
    

    scrKeep     db 16*16 dup (?) ; Saved background behind sprite
    
    snakeX      dw 300  dup (?) ; Snake body X coordinates
    snakeY      dw 300  dup (?) ; Snake body Y coordinates
    len         db 0 ; current length of the snake
    direction   db 2 ;start with left 1=right 2=left 3=up 4=down
    chackSlf    db 0 ;0=don't hit the body 1= hit the body
    
    ;apple
    appleX      dw ?  ; Apple X position
    appleY      dw ?  ; Apple Y position
    chackApl    db 0 ; 0 = apple not eaten, 1 = apple eaten
   
    Hz          dw ? ;frequency to play sound
    prevTime    dw ? ;Previous clock tick value for delay timing
    
    dmut        dw ? ; Pointer to current snake skin to print
    skin        db 1;start with green 1=green 2=blue 3=red 4=purple 5=green-black 6=blue-black 7=red-black 8=purple-black 9=snowman
    
    ;BMP
    filenameH   db 'homeScr.bmp',0 ; Home screen BMP filename
    filenameI   db 'instScr.bmp',0 ; Instructions screen BMP filename
    filenameL   db 'loseScr.bmp',0 ; Lose screen BMP filename
    filenameS   db 'skinScr.bmp',0 ; Skin screen BMP filename
    filenameLb  db 'leadBScr.bmp',0 ; Leaderboard BMP filename
    filehandle  dw ? ; Dos file handle
    currentFile dw ? ; the current bmp file to display
    
    Header      db 54 dup (0) ; BMP header buffer
    Palette     db 256*4 dup (0)  ; BMP palette buffer
    ScrLine     db 320 dup (0) ; Buffer for one BMP scan line
    
    picHigh     dw ? ; image height
    picWidth    dw ? ; image width
    leftGap     dw ? ; columns gap
    topGap      dw ? ; rows gap (mult by 320)
    
    ;leaderboard
    score       db 0 ;Current player score
    divTable    db 100,10,1  ;  used for number printing
    scoreMsg    db "Score:$" ;  string to print
    scoreFile   db 'scores.dat',0 ; Score data filename
    topScores   db 5 dup(0) ; Top 5 high scores

; --------------------------
CODESEG

include "SnakeP.asm"

start:  

    mov ax, @data
    mov ds, ax 


    call loadTop5
    graphicMode
    
;---------------------------------------------- 
;HOME SCREEN  
;---------------------------------------------- 
homeScr:
    graphicMode
    ;print the home screen 
    setImgVars filenameH
    call printPic
homeInp:    
    ;get input from the user
    getInp
    
    cmp al,20h ;space
    je  game
    
    cmp al,69h ; i
    je  instarctionsScr
    
    cmp al,73h ;s
    je  skinScr
    
    cmp al,'l' ;l
    je  leadebroardScr
    
    cmp al,1Bh ;esc
    je  exit
    
    jmp homeInp
    
    
;---------------------------------------------- 
;INSTARCTIONS SCREEN  
;----------------------------------------------    
instarctionsScr:
    graphicMode
    ;print the instarctions screen 
    setImgVars filenameI
    call printPic
instInp:    
    ;get input from the user
    getInp
    
    cmp al,68h ;h
    je  homeScr
   
    jmp instInp

;---------------------------------------------- 
;LEADEBROARD SCREEN  
;---------------------------------------------- 
leadebroardScr:
    graphicMode
    ;print the leaderboard screen 
    setImgVars filenameLb
    call printPic
    
    call printTop5

leaderInp:

    getInp

    cmp al,68h   ; h
    je homeScr

    jmp leaderInp
    
    
;---------------------------------------------- 
;SKIN SCREEN  
;---------------------------------------------- 
skinScr:
    ;print the home screen 
    setImgVars filenameS
    call printPic
skinInp:    
    ;get input from the user
    getInp
    
    cmp al,68h;h
    je homeScr
    
    cmp al,'1' ;green
    je  S1
    
    cmp al,'2' ;blue
    je  S2
    
    cmp al,'3' ;red
    je  S3
    
    cmp al,'4' ;purple
    je  S4
    
    cmp al,'5' ;green black
    je  S5
    
    cmp al,'6' ;blue black
    je  S6
    
    cmp al,'7' ;red black
    je  S7
    
    cmp al,'8' ;purple black
    je  S8
    
    cmp al,'9' ;snowman
    je  S9
    
    jmp skinInp
S1:
    mov [skin],1 ;green
    jmp homeScr
S2:
    mov [skin],2 ;blue
    jmp homeScr
S3:
    mov [skin],3 ;red
    jmp homeScr
S4:
    mov [skin],4 ;purple
    jmp homeScr    
S5:
    mov [skin],5 ;green black
    jmp homeScr
S6:
    mov [skin],6 ;blue black
    jmp homeScr
S7:
    mov [skin],7 ;red black
    jmp homeScr
S8:
    mov [skin],8 ;purple black
    jmp homeScr   
S9:
    mov [skin],9 ;snowman
    jmp homeScr
   
   
;---------------------------------------------- 
;Main GAME SCREEN  
;----------------------------------------------  
game:  
    ; reset variables
    call gameStart
    ;drawing Background
    call drawBackground
    
waitForkey:
   ;get input from the user
    getInp   
      
    cmp al, 00h ; chack if the input is special tav
    jne regKey

    getInp ;which spaicial key it is 
    
    cmp al,4Dh ; right
    je  moveRight
    
    cmp al,4Bh ; left
    je  moveLeft
    
    cmp al,48h ; up
    je  moveUp 
    
    cmp al,50h ; down
    je  moveDown

regKey:    
    ; if input is not the arroy keys go back to the direction befor
    cmp [direction],1 ;right
    je moveRight 
    
    cmp [direction],2 ;left
    je moveLeft  
    
    cmp [direction],3 ;up
    je moveUp 
    
    cmp [direction],4 ;down
    je moveDown
        
    jmp waitForkey

;---------------------------------------------- 
;RIGHT  
;----------------------------------------------      
moveRight: 
     
    cmp [direction],2 ;if the last direction was left dont move right keep moving left
    je moveLeft
    
    mov [direction],1 ;right
   
    prepShR
    call shRight
    
    ;chack wall hit   
    mov ax,[snakeX]
    add ax,16 ;future location
    mov [x],ax
   
    mov ax,[snakeY]
    mov [y],ax
     
    cmp [x],312;if x is in the end of screen don't move right  
    je loseScr
    
    ;chack self hit  
    call chackBd
    cmp [chackSlf],1
    je loseScr
      
    ;chack future location for apple
    mov ax,[x];compare x
    cmp [appleX],ax
    jne notApR
    
    mov ax,[y];compare y
    cmp [appleY],ax
    jne notApR
    
    ;delete the apple
    call delApple
    
    inc [len]
    inc [score]
    ;print score
    xor ax,ax
    mov al,[score]
    setCurser  1,19

    call printNumber
    
    ;generate random coordinates
    call randomAp
    
    ;draw apple
    call drawApl
    
    jmp drawR
    
notApR:
    ;deleting old tail
    call delTail

drawR:
    
    call newHeadR ;drawing new head
    
    cmp [chackApl],1 ;if he eat an apple no need for delay  because of the sound delay
    je  playSndR  
    
    mov cx,5   ; 5x0.055sec = 0.3sec
    call delay
    jmp nextR
    
playSndR: 
    ;play sound
    call aplSound
    
    mov [chackApl],0;back to false

nextR:    
    ; chack input
    chackInp
    cmp al,0
    je moveRight
    jmp waitForkey
    
;---------------------------------------------- 
;LEFT  
;---------------------------------------------- 
moveLeft: 
    
    cmp [direction],1 ;if the last direction was right dont move left keep moving right
    je moveRight
    
    mov [direction],2 ;left

    prepShR
    call shRight
 
    
    ;chack wall hit    
    mov ax,[snakeX]
    dec ax;future location
    mov [x],ax
   
    mov ax,[snakeY]
    mov [y],ax 
    
    cmp [x],7;if x is in the beggining of screen dont move left  
    je loseScr
    
    ;chack self hit
    sub [x],15 ; x-16 future location
    
    call chackBd
    cmp [chackSlf],1
    je loseScr
      
    
    ;chack future location for apple
    mov ax,[snakeX];compare x
    sub ax,16 ;next place
    cmp [appleX],ax
    jne notApL
    
    mov ax,[snakeY];compare y
    cmp [appleY],ax
    jne notApL
   
    ;delete the apple
    call delApple
    
    call calcPos
    call retSQR
    
    inc [len]
    inc [score]
    ;print score
    xor ax,ax
    mov al,[score]
    setCurser  1,19

    call printNumber
    
    ;generate random coordinates
    call randomAp
    
    ;draw apple
    call drawApl
        
    jmp drawL

notApL:    
    ;deleting old tail
    call delTail
    
drawL: 
    
    call newHeadL ;drawing new head
      
    cmp [chackApl],1 ;if he eat an apple no need for delay  because of the sound delay
    je  playSndL  
    
    mov cx,5   ; 5x0.055sec = 0.3sec
    call delay
    jmp nextL
    
playSndL: 
    ;play sound
    call aplSound
    
    mov [chackApl],0;back to false

nextL:
    
    ;chack input
    chackInp
    cmp al,0
    je moveLeft
    jmp waitForkey

;---------------------------------------------- 
;UP  
;---------------------------------------------- 
moveUp: 
   
    cmp [direction],4 ;if the last direction was down dont move up keep moving down
    je moveDown
    
    mov [direction],3 ;up

    prepShR
    call shRight
     
    ;chack wall hit
    mov ax,[snakeX]
    mov [x],ax
       
    mov ax,[snakeY]
    dec ax ;future location
    mov [y],ax
    
    cmp [y],27 ;if y is in the biggening of screen dont move up  
    je loseScr
    
    ;chack self hit
    sub [y],15 ; y-16 future location
    
    call chackBd
    cmp [chackSlf],1
    je loseScr

    ;chack future location for apple
    mov ax,[snakeX];compare x
    cmp [appleX],ax
    jne notApU
    
    mov ax,[snakeY];compare y
    sub ax,16 ;next place
    cmp [appleY],ax
    jne notApU

    ;delete the apple
    call delApple
    
    call calcPos
    call retSQR
    
    inc [len]
    inc [score]
    ;print score
    xor ax,ax
    mov al,[score]
    setCurser  1,19

    call printNumber
    
    ;generate random coordinates
    call randomAp
    
    ;draw apple
    call drawApl
     
    jmp drawU

notApU:
    ;deleting old tail
    call delTail
    
drawU:    
    
    call newHeadU ;drawing new head
    
    cmp [chackApl],1 ;if he eat an apple no need for delay  because of the sound delay
    je  playSndU 
    
    mov cx,5   ; 5x0.055sec = 0.3sec
    call delay
    jmp nextU
    
playSndU: 
    ;play sound
    call aplSound
        
    mov [chackApl],0;back to false

nextU:
    
    ;chack input
    chackInp
    cmp al,0
    je moveUp
    jmp waitForkey
    
;---------------------------------------------- 
;DOWN  
;---------------------------------------------- 
moveDown: 
    
    cmp [direction],3 ;if the last direction was up dont move down keep moving up
    je moveUp
    
    mov [direction],4 ;down
        
    prepShR
    call shRight
 
   
    ;chack wall hit
    mov ax,[snakeX]
    mov [x],ax
       
    mov ax,[snakeY]
    add ax,16;future location
    mov [y],ax
   
    cmp [y],188;if y is in the end of screen dont move up  
    je loseScr

    ;chack self hit    
    call chackBd
    cmp [chackSlf],1
    je loseScr
    
   ;chack future location for apple
    mov ax,[snakeX];compare x
    cmp [appleX],ax
    jne notApD
    
    mov ax,[snakeY];compare y
    add ax,16 ;next place
    cmp [appleY],ax
    jne notApD
    
    ;delete the apple
    call delApple
    
    call calcPos
    call retSQR
    
    inc [len]
    inc [score]
    ;print score
    xor ax,ax
    mov al,[score]
    setCurser  1,19

    call printNumber
    
    ;generate random coordinates
    call randomAp
    ;draw apple
    call drawApl
        
    jmp drawD
 
notApD:
    ;deleting old tail
    call delTail
    
drawD:   
    call newHeadD ;drawing new head
    
    cmp [chackApl],1 ;if he eat an apple no need for delay  because of the sound delay
    je  playSndD 
    
    mov cx,5   ; 5x0.055sec = 0.3sec
    call delay
    jmp nextD
    
playSndD: 
    ;play sound
    call aplSound
    
    mov [chackApl],0;back to false

nextD:
 
    ;chack input
    chackInp
    cmp al,0
    je moveDown
    jmp waitForkey   
  
;---------------------------------------------- 
;LOSE SCREEN  
;---------------------------------------------- 
loseScr:
    
    call updateTop5
    call saveTop5
    
    ;play sound
    call loseSound
    ;print the lose screen 
    setImgVars filenameL
    call printPic
    
    
loseInp:    
    ;get input from the user
    getInp
    
    cmp al,72h ;r
    je  game
    
    cmp al,68h ; h
    je  homeScr
        
    jmp loseInp
    

exit:
    textMode
    mov ax, 4c00h
    int 21h
END start
