;entering graphic mode
graphicMode macro
    mov ax, 13h
    int 10h
endm
;entering text mode
textMode macro
    mov ax, 3
    int 10h
endm

wait4key macro
    ;wait for key pressed
    mov ah,0h 
    int 16h
endm


;enter p1,p2
;exit mov p1 to wide and p2 to high
setParam macro p1, p2
    mov [wide], p1
    mov [high], p2
endm

;enter Clock
;exit time in ax
takeTime macro
    mov ax,40h
    mov es,ax
    mov ax,[Clock]
endm

;enter len
;exit move len to cx and move si (len-1)*2
prepShR macro
    xor cx,cx
    mov cl,[len]
    mov si,cx
    shl si,1 ;si=2*len
    sub si,2
endM  

;chack if there is input
chackInp macro
    ;chack input
    mov ah,0Bh
    int 21h
endM 

;get input
getInp macro
    ;get input from the user
    mov ah,7h
    int 21h 
endM 

; send control word to change frequency
frequency macro
    mov al, 0B6h
    out 43h, al
endm 
    
;open the speaker
openSpeaker macro
    in al,61h
    or al,00000011b
    out 61h,al
endM
    
;close the speaker
closeSpeaker macro
    in al,61h
    and al,11111100b
    out 61h,al
endM

;enter row,line
;exit set curser
setCurser macro row,line
    mov bh,0
    mov dh,row
    mov dl,line
    mov ah,2h
    int 10H
endm

;enter name
;exit set vars
setImgVars macro name
    mov [currentFile], offset name
    mov [picHigh], 200
    mov [picWidth], 320
    mov [leftGap], 0
    mov [topGap],0
endm

;enter name
;exit location of name to dmut
setDmut macro name
    mov [dmut],offset name
endm

;drawing snake
drawS macro 
    call calcPos 
    call takeSQR
    call andingS    
    call oringS
endm

;drawing apple
drawA macro 
    call calcPos 
    call takeSQR
    call andingA    
    call oringA
endm
